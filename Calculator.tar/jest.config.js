module.exports = {
    testEnvironment: 'node',
}