const {expect, test} = require('@jest/globals');
const { calculatorFun } = require('../srv/calculator-service')


test('POST calculation records', async() => {
    console.log(typeof calculatorFun)
    const operator = 'add';
    const value1 = 1;
    const value2 = 2;
  const result = await calculatorFun(operator,value1,value2);
  expect(parseInt(result)).toBe(3);
});

